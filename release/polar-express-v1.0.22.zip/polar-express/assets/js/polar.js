/**
 * Polar Express Dashboard JavaScript
 *
 * @package PExpress
 * @since 1.0.0
 */

(function ($) {
    'use strict';

    // Initialize when document is ready
    $(document).ready(function () {
        initHeartbeat();
        initAssignmentForms();
        initStatusUpdateForms();
        initSupportDashboardFilters();
        initTabs();
        initAgencyDashboardFilters();
        initHistoryRowExpansion();
        initProceedOrder();
    });

    /**
     * Initialize WordPress Heartbeat for real-time updates
     */
    function initHeartbeat() {
        // Ensure heartbeat is enabled
        if (typeof wp === 'undefined' || typeof wp.heartbeat === 'undefined') {
            return;
        }

        // Trigger heartbeat every 15 seconds
        setInterval(function () {
            wp.heartbeat.connectNow();
        }, 15000);

        // Listen for heartbeat tick
        $(document).on('heartbeat-tick', function (e, data) {
            if (data.polar_tasks) {
                updateTaskList(data.polar_tasks);
            }

            // Update real-time status for support dashboard
            if (data.polar_order_tracking) {
                updateRealtimeStatus(data.polar_order_tracking);
            }
        });

        // Request order tracking data for visible orders
        $(document).on('heartbeat-send', function (e, data) {
            var orderIds = [];
            $('.polar-realtime-status').each(function () {
                var orderId = $(this).data('order-id');
                if (orderId) {
                    orderIds.push(orderId);
                }
            });

            if (orderIds.length > 0) {
                data.polar_order_tracking = {
                    order_ids: orderIds
                };
            }
        });
    }

    /**
     * Update task list with new data
     */
    function updateTaskList(tasks) {
        // Update visual indicator
        $('.polar-dashboard').each(function () {
            var $dashboard = $(this);
            var $indicator = $dashboard.find('.polar-update-indicator');

            if ($indicator.length === 0) {
                $dashboard.find('h2').append('<span class="polar-update-indicator"></span>');
            }
        });

        // Reload the page after a short delay to show updated data
        // In a production environment, you might want to do AJAX updates instead
        setTimeout(function () {
            // Optional: Use AJAX to refresh specific sections instead of full page reload
            // For now, we'll just show the indicator
        }, 500);
    }

    /**
     * Initialize assignment forms (Agent Dashboard)
     */
    function initAssignmentForms() {
        $('.polar-assign-form').on('submit', function (e) {
            e.preventDefault();

            var $form = $(this);
            var orderId = $form.data('order-id');
            var $button = $form.find('button[type="submit"]');

            // Disable button
            $button.prop('disabled', true).html('<svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 6px; vertical-align: middle;"><path d="M13 10V3L4 14H11V21L20 10H13Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>Assigning & Proceeding...');

            // Prepare form data
            var formData = $form.serialize();
            formData += '&action=polar_assign_order';
            formData += '&order_id=' + orderId;

            // Submit via AJAX
            $.ajax({
                url: polarExpress.ajaxUrl,
                type: 'POST',
                data: formData,
                success: function (response) {
                    if (response.success) {
                        $form.closest('.polar-order-item').fadeOut(300, function () {
                            $(this).remove();
                        });
                        showNotice('Order assigned successfully!', 'success');
                    } else {
                        showNotice(response.data.message || 'Failed to assign order.', 'error');
                        $button.prop('disabled', false).html('<svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 6px; vertical-align: middle;"><path d="M13 10V3L4 14H11V21L20 10H13Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>Assign & Proceed Order');
                    }
                },
                error: function () {
                    showNotice('An error occurred. Please try again.', 'error');
                    $button.prop('disabled', false).html('<svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 6px; vertical-align: middle;"><path d="M13 10V3L4 14H11V21L20 10H13Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>Assign & Proceed Order');
                }
            });
        });
    }

    /**
     * Initialize status update forms
     */
    function initStatusUpdateForms() {
        $('.polar-status-update-form, .polar-fridge-status-form, .polar-distributor-status-form').each(function () {
            var $form = $(this);
            $form.find('button[type="submit"]').on('click', function () {
                $form.data('clicked-button', $(this));
            });
        }).on('submit', function (e) {
            e.preventDefault();

            var $form = $(this);
            var orderId = $form.data('order-id');
            var $statusField = $form.find('[name="status"]').not('button');
            var $button = $form.data('clicked-button');

            if (!$button || $button.length === 0) {
                $button = $form.find('button[type="submit"]').first();
            }

            var newStatus = $statusField.length ? $statusField.val() : '';
            if (!newStatus) {
                newStatus = $button.val();
            }

            // Disable button
            if ($button && $button.length) {
                $button.prop('disabled', true);
                if (!$button.data('original-text')) {
                    $button.data('original-text', $.trim($button.text()) || '');
                }
                $button.text('Updating...');
            }

            // Prepare form data
            var formData = $form.serialize();
            formData += '&action=polar_update_order_status';
            formData += '&order_id=' + orderId;
            formData += '&status=' + newStatus;

            // Submit via AJAX
            $.ajax({
                url: polarExpress.ajaxUrl,
                type: 'POST',
                data: formData,
                success: function (response) {
                    if (response.success) {
                        var message = 'Order status updated successfully!';
                        if (response.data && response.data.new_status) {
                            message = 'Status updated to: ' + response.data.new_status;
                        }
                        showNotice(message, 'success');

                        // Determine which tab the order should appear in after status update
                        var $taskItem = $form.closest('.polar-task-item');
                        var newStatus = $button.val();
                        var targetTab = 'pending';

                        // Map status to target tab based on role
                        if ($form.hasClass('polar-fridge-status-form')) {
                            if (newStatus === 'fridge_returned') {
                                targetTab = 'completed';
                            } else if (newStatus === 'fridge_drop' || newStatus === 'fridge_collected') {
                                targetTab = 'in-progress';
                            }
                        } else if ($form.hasClass('polar-distributor-status-form')) {
                            if (newStatus === 'handoff_complete') {
                                targetTab = 'completed';
                            } else if (newStatus === 'distributor_prep' || newStatus === 'out_for_delivery') {
                                targetTab = 'in-progress';
                            }
                        } else if ($form.hasClass('polar-status-update-form')) {
                            if (newStatus === 'service_complete' || newStatus === 'customer_served') {
                                targetTab = 'completed';
                            } else if (newStatus === 'meet_point_arrived' || newStatus === 'delivery_location_arrived' || newStatus === 'service_in_progress') {
                                targetTab = 'in-progress';
                            }
                        }

                        // Reload page with cache-bust and preserve target tab
                        setTimeout(function () {
                            var baseUrl = location.href.split('?')[0].split('#')[0];
                            location.href = baseUrl + '?t=' + Date.now() + '#tab-' + targetTab;
                        }, 800);
                    } else {
                        showNotice(response.data.message || 'Failed to update status.', 'error');
                        if ($button && $button.length) {
                            $button.prop('disabled', false).text($button.data('original-text') || 'Update');
                        }
                    }
                    $form.removeData('clicked-button');
                },
                error: function () {
                    showNotice('An error occurred. Please try again.', 'error');
                    if ($button && $button.length) {
                        $button.prop('disabled', false).text($button.data('original-text') || 'Update');
                    }
                    $form.removeData('clicked-button');
                }
            });
        });
    }

    /**
     * Initialize Agent Dashboard filters and search (uses delegation so it works when content loads later)
     */
    function initAgencyDashboardFilters() {
        function getAgencyFilterContext() {
            var $statusFilter = $('#polar-agency-status-filter');
            var $searchInput = $('#polar-agency-search');
            var $ordersSection = $statusFilter.length ? $statusFilter.closest('.polar-orders-section') : $searchInput.closest('.polar-orders-section');
            if (!$ordersSection.length && $searchInput.length) {
                $ordersSection = $searchInput.closest('.polar-orders-section');
            }
            return { $statusFilter: $statusFilter, $searchInput: $searchInput, $ordersSection: $ordersSection };
        }

        function filterAgencyOrders() {
            var ctx = getAgencyFilterContext();
            var $statusFilter = ctx.$statusFilter;
            var $searchInput = ctx.$searchInput;
            var $ordersSection = ctx.$ordersSection;

            if (typeof console !== 'undefined' && console.log) {
                console.log('[Polar Agency Filter] filterAgencyOrders ran', {
                    hasOrdersSection: !!$ordersSection.length,
                    hasStatusFilter: !!$statusFilter.length,
                    hasSearchInput: !!$searchInput.length,
                    searchValue: ($searchInput.val() || '').trim(),
                    statusValue: ($statusFilter.val() || '').trim()
                });
            }

            if (!$ordersSection.length || !$statusFilter.length || !$searchInput.length) {
                if (typeof console !== 'undefined' && console.warn) {
                    console.warn('[Polar Agency Filter] Early return: missing context', {
                        ordersSection: $ordersSection.length,
                        statusFilter: $statusFilter.length,
                        searchInput: $searchInput.length
                    });
                }
                return;
            }

            var statusValue = ($statusFilter.val() || '').trim();
            var searchValue = ($searchInput.val() || '').toLowerCase().trim();
            var $activeContent = $ordersSection.find('.polar-tab-content.active');

            // Fallback: if no .active (e.g. hash set before click), use hash or first tab
            if (!$activeContent.length) {
                var tabId = (typeof location !== 'undefined' && location.hash && location.hash.indexOf('tab-') !== -1)
                    ? location.hash.replace('#tab-', '') : 'pending';
                $activeContent = $ordersSection.find('#tab-' + tabId);
                if ($activeContent.length) {
                    $ordersSection.find('.polar-tab-content').removeClass('active');
                    $ordersSection.find('.polar-tab').removeClass('active');
                    $activeContent.addClass('active');
                    $ordersSection.find('.polar-tab[data-tab="' + tabId + '"]').addClass('active');
                }
            }
            if (!$activeContent.length) {
                $activeContent = $ordersSection.find('.polar-tab-content').first();
            }

            var $orders = $activeContent.find('.polar-order-item');
            var visibleCount = 0;

            if (typeof console !== 'undefined' && console.log) {
                console.log('[Polar Agency Filter] Context', {
                    activeContentId: $activeContent.attr('id'),
                    activeContentLength: $activeContent.length,
                    ordersCount: $orders.length,
                    statusValue: statusValue,
                    searchValue: searchValue
                });
            }

            $orders.each(function (index) {
                var $order = $(this);
                var orderStatus = ($order.attr('data-status') || '').trim();
                var orderId = String($order.attr('data-order-id') || '');
                var orderText = $order.text().toLowerCase();
                var customerName = ($order.find('.customer-name').text() || '').toLowerCase().trim();
                var phoneNumber = ($order.find('.phone-number').text() || '').toLowerCase().trim().replace(/\s/g, '');

                var normalizedOrderStatus = orderStatus.replace(/^wc-/, '');
                var normalizedFilterStatus = statusValue.replace(/^wc-/, '');

                var statusMatch = !statusValue ||
                    orderStatus === statusValue ||
                    orderStatus === 'wc-' + normalizedFilterStatus ||
                    normalizedOrderStatus === normalizedFilterStatus ||
                    normalizedOrderStatus === statusValue;

                var searchMatch = !searchValue ||
                    orderText.indexOf(searchValue) !== -1 ||
                    orderId.indexOf(searchValue) !== -1 ||
                    customerName.indexOf(searchValue) !== -1 ||
                    phoneNumber.indexOf(searchValue) !== -1;

                if (statusMatch && searchMatch) {
                    $order.css('display', '');
                    visibleCount++;
                } else {
                    $order.css('display', 'none');
                }

                if (typeof console !== 'undefined' && console.log && index < 3) {
                    console.log('[Polar Agency Filter] Order #' + orderId, {
                        orderId: orderId,
                        orderStatus: orderStatus,
                        customerName: customerName,
                        phoneNumber: phoneNumber,
                        statusMatch: statusMatch,
                        searchMatch: searchMatch,
                        visible: statusMatch && searchMatch
                    });
                }
            });

            if (typeof console !== 'undefined' && console.log) {
                console.log('[Polar Agency Filter] Result', { visibleCount: visibleCount, totalOrders: $orders.length });
            }

            var $emptyState = $activeContent.find('.polar-filter-empty-state');
            if (visibleCount === 0 && $orders.length > 0) {
                if (!$emptyState.length) {
                    $activeContent.append(
                        '<div class="polar-empty-state polar-filter-empty-state">' +
                        '<p>No orders match your filters.</p>' +
                        '</div>'
                    );
                }
                $activeContent.find('.polar-filter-empty-state').show();
            } else {
                $activeContent.find('.polar-filter-empty-state').hide();
            }
        }

        // Delegate so search/filter work even when dashboard is injected after DOM ready
        $(document).on('input', '#polar-agency-search', function () {
            clearTimeout($(this).data('polar-timeout'));
            $(this).data('polar-timeout', setTimeout(filterAgencyOrders, 300));
        });
        $(document).on('change', '#polar-agency-status-filter', filterAgencyOrders);
        $(document).on('click', '.polar-orders-section .polar-tab', function () {
            setTimeout(filterAgencyOrders, 100);
        });
        // Run once on load in case dashboard is already in DOM
        setTimeout(filterAgencyOrders, 150);
    }

    /**
     * Initialize tabs functionality
     */
    function initTabs() {
        // Check for hash on page load to restore active tab
        if (location.hash && location.hash.startsWith('#tab-')) {
            var tabId = location.hash.replace('#tab-', '');
            var $tab = $('.polar-tab[data-tab="' + tabId + '"]');
            if ($tab.length) {
                var $tabs = $tab.closest('.polar-tabs').find('.polar-tab');
                var $contents = $tab.closest('.polar-tasks-section, .polar-orders-section').find('.polar-tab-content');

                // Remove active class from all tabs and contents
                $tabs.removeClass('active');
                $contents.removeClass('active');

                // Add active class to target tab and corresponding content
                $tab.addClass('active');
                $('#tab-' + tabId).addClass('active');
            }
        }

        $('.polar-tab').on('click', function () {
            var $tab = $(this);
            var tabId = $tab.data('tab');
            var $tabs = $tab.closest('.polar-tabs').find('.polar-tab');
            var $contents = $tab.closest('.polar-tasks-section, .polar-orders-section').find('.polar-tab-content');

            // Remove active class from all tabs and contents
            $tabs.removeClass('active');
            $contents.removeClass('active');

            // Add active class to clicked tab and corresponding content
            $tab.addClass('active');
            $('#tab-' + tabId).addClass('active');

            // Re-apply Support dashboard filter when switching tabs
            if ($('#polar-support-orders').length) {
                $('#polar-status-filter').trigger('change');
            }

            // Update URL hash without triggering scroll
            if (history.replaceState) {
                history.replaceState(null, null, '#tab-' + tabId);
            } else {
                location.hash = '#tab-' + tabId;
            }
        });
    }

    /**
     * Initialize Support Dashboard filters and search
     */
    function initSupportDashboardFilters() {
        var $statusFilter = $('#polar-status-filter');
        var $searchInput = $('#polar-search');
        var $ordersList = $('#polar-support-orders');

        if ($statusFilter.length === 0 || $searchInput.length === 0 || $ordersList.length === 0) {
            return;
        }

        function filterOrders() {
            var statusValue = $statusFilter.val();
            var searchValue = $searchInput.val().toLowerCase().trim();
            var $activeContent = $ordersList.find('.polar-tab-content.active');
            var $orders = $activeContent.find('.polar-order-item');
            var visibleCount = 0;

            $orders.each(function () {
                var $order = $(this);
                var orderStatus = $order.data('status') || '';
                var orderId = $order.data('order-id') || '';
                var orderText = $order.text().toLowerCase();
                var customerName = $order.find('.customer-name').text().toLowerCase();
                var phoneNumber = $order.find('.phone-number').text().toLowerCase();

                // Normalize status values for comparison
                var normalizedOrderStatus = orderStatus.replace('wc-', '');
                var normalizedFilterStatus = statusValue.replace('wc-', '');

                var statusMatch = !statusValue ||
                    orderStatus === statusValue ||
                    orderStatus === 'wc-' + statusValue ||
                    normalizedOrderStatus === normalizedFilterStatus ||
                    orderStatus === normalizedFilterStatus ||
                    'wc-' + normalizedOrderStatus === statusValue;

                var searchMatch = !searchValue ||
                    orderText.indexOf(searchValue) !== -1 ||
                    orderId.toString().indexOf(searchValue) !== -1 ||
                    customerName.indexOf(searchValue) !== -1 ||
                    phoneNumber.indexOf(searchValue) !== -1;

                if (statusMatch && searchMatch) {
                    $order.fadeIn(200);
                    visibleCount++;
                } else {
                    $order.fadeOut(200);
                }
            });

            // Show empty state if no orders visible
            var $emptyState = $activeContent.find('.polar-filter-empty-state');
            if (visibleCount === 0 && $orders.length > 0) {
                if ($emptyState.length === 0) {
                    $activeContent.append(
                        '<div class="polar-empty-state polar-filter-empty-state">' +
                        '<div class="empty-state-icon">' +
                        '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">' +
                        '<path d="M21 21L15 15M17 10C17 13.866 13.866 17 10 17C6.13401 17 3 13.866 3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>' +
                        '</svg>' +
                        '</div>' +
                        '<h3>No orders found</h3>' +
                        '<p>Try adjusting your filters or search terms.</p>' +
                        '</div>'
                    );
                }
                $activeContent.find('.polar-filter-empty-state').fadeIn(200);
            } else {
                $activeContent.find('.polar-filter-empty-state').fadeOut(200);
            }
        }

        // Bind events
        $statusFilter.on('change', filterOrders);
        $searchInput.on('input', function () {
            clearTimeout($searchInput.data('timeout'));
            var timeout = setTimeout(filterOrders, 300);
            $searchInput.data('timeout', timeout);
        });
    }

    /**
     * Initialize history row expansion
     */
    function initHistoryRowExpansion() {
        $(document).on('click', '.polar-toggle-details', function (e) {
            e.preventDefault();
            var $button = $(this);
            var orderId = $button.data('order-id');
            var $detailsRow = $('.polar-history-details[data-order-id="' + orderId + '"]');
            var $historyRow = $('.polar-history-row[data-order-id="' + orderId + '"]');

            if ($detailsRow.length === 0) {
                return;
            }

            if ($detailsRow.is(':visible')) {
                $detailsRow.slideUp(200);
                $button.text('View');
                $historyRow.removeClass('expanded');
            } else {
                $detailsRow.slideDown(200);
                $button.text('Hide');
                $historyRow.addClass('expanded');
            }
        });

        // Make entire row clickable for better UX
        $(document).on('click', '.polar-history-row', function (e) {
            // Don't trigger if clicking on a link or button
            if ($(e.target).is('a, button, .polar-toggle-details')) {
                return;
            }
            var $row = $(this);
            var orderId = $row.data('order-id');
            var $button = $row.find('.polar-toggle-details');
            if ($button.length) {
                $button.trigger('click');
            }
        });
    }

    /**
     * Initialize Proceed Order button
     */
    function initProceedOrder() {
        $(document).on('click', '.polar-proceed-order', function (e) {
            e.preventDefault();
            e.stopPropagation();

            var $button = $(this);
            var orderId = parseInt($button.data('order-id'), 10);
            var nonce = $button.data('nonce');
            var $feedback = $button.siblings('.polar-proceed-feedback');

            if (!orderId || !nonce) {
                return;
            }

            $button.prop('disabled', true).addClass('is-loading');
            if ($feedback.length === 0) {
                $feedback = $('<span class="polar-proceed-feedback" role="status" aria-live="polite"></span>');
                $button.after($feedback);
            }
            $feedback.removeClass('is-error is-success').text('Proceeding...');

            $.ajax({
                url: polarExpress.ajaxUrl,
                method: 'POST',
                dataType: 'json',
                data: {
                    action: 'polar_proceed_order',
                    nonce: nonce,
                    order_id: orderId,
                },
            })
                .done(function (response) {
                    if (!response || !response.success) {
                        var message = response && response.data && response.data.message
                            ? response.data.message
                            : 'Unable to proceed order. Please try again.';
                        $feedback.addClass('is-error').text(message);
                        return;
                    }

                    $feedback.addClass('is-success').text(response.data.message || 'Order proceeded successfully.');
                    $button.replaceWith('<span class="polar-action-status" style="display: inline-flex; align-items: center; color: #46b450;"><span class="dashicons dashicons-yes-alt" style="font-size: 16px; width: 16px; height: 16px;"></span> Proceeded</span>');

                    setTimeout(function () {
                        $feedback.removeClass('is-success').text('');
                    }, 3000);
                })
                .fail(function () {
                    $feedback.addClass('is-error').text('Unable to proceed order. Please try again.');
                })
                .always(function () {
                    $button.prop('disabled', false).removeClass('is-loading');
                });
        });
    }

    /**
     * Update real-time status cards
     */
    function updateRealtimeStatus(trackingData) {
        if (!trackingData) {
            return;
        }

        // Handle array of tracking data (multiple orders)
        var dataArray = Array.isArray(trackingData) ? trackingData : [trackingData];

        dataArray.forEach(function (data) {
            if (!data || !data.statuses || !data.order_id) {
                return;
            }

            var orderId = data.order_id;
            var $statusContainer = $('.polar-realtime-status[data-order-id="' + orderId + '"]');

            if (!$statusContainer.length) {
                return;
            }

            var statuses = data.statuses;
            var statusLabels = {
                'agency': {
                    'pending': 'Pending',
                    'assigned': 'Assigned',
                    'proceeded': 'Proceeded'
                },
                'delivery': {
                    'pending': 'Pending',
                    'meet_point_arrived': 'Meet Point Arrived',
                    'delivery_location_arrived': 'Delivery Location Arrived',
                    'service_in_progress': 'Service In Progress',
                    'service_complete': 'Service Complete',
                    'customer_served': 'Customer Served'
                },
                'fridge': {
                    'pending': 'Pending',
                    'fridge_drop': 'Fridge Dropped',
                    'fridge_collected': 'Fridge Collected',
                    'fridge_returned': 'Fridge Returned'
                },
                'distributor': {
                    'pending': 'Pending',
                    'distributor_prep': 'Product Provider Preparing',
                    'out_for_delivery': 'Out for Delivery',
                    'handoff_complete': 'Product Provider Handoff Complete'
                }
            };

            function getStatusClass(status) {
                if (['customer_served', 'handoff_complete', 'fridge_returned', 'proceeded'].indexOf(status) !== -1) {
                    return 'success';
                } else if (status === 'pending') {
                    return 'pending';
                } else {
                    return 'in-progress';
                }
            }

            function getStatusLabel(role, status) {
                if (statusLabels[role] && statusLabels[role][status]) {
                    return statusLabels[role][status];
                }
                return status.replace(/_/g, ' ').replace(/\b\w/g, function (l) { return l.toUpperCase(); });
            }

            // Update each status card
            $.each(statuses, function (role, roleData) {
                var $card = $statusContainer.find('.polar-status-mini-card[data-role="' + role + '"]');
                if ($card.length && roleData.status) {
                    var $badge = $card.find('.polar-status-badge-mini');
                    var statusClass = getStatusClass(roleData.status);
                    var statusLabel = getStatusLabel(role, roleData.status);

                    $badge.removeClass('polar-status-success polar-status-pending polar-status-in-progress')
                        .addClass('polar-status-' + statusClass)
                        .text(statusLabel);
                }
            });
        });
    }

    /**
     * Show notice message
     */
    function showNotice(message, type) {
        type = type || 'info';

        var $notice = $('<div class="polar-notice polar-notice-' + type + '">' + message + '</div>');
        $notice.css({
            position: 'fixed',
            top: '20px',
            right: '20px',
            padding: '15px 20px',
            background: type === 'success' ? '#00a32a' : '#d63638',
            color: '#fff',
            borderRadius: '4px',
            zIndex: 9999,
            boxShadow: '0 2px 8px rgba(0,0,0,0.2)'
        });

        $('body').append($notice);

        // Remove after 3 seconds
        setTimeout(function () {
            $notice.fadeOut(300, function () {
                $(this).remove();
            });
        }, 3000);
    }

})(jQuery);

